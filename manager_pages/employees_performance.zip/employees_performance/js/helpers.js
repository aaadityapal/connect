/**
 * helpers.js — Helper Functions for Employees Performance
 */

function getGrade(score) {
    if (score >= 90) return { label: 'Excellent', cls: 'badge-excellent' };
    if (score >= 75) return { label: 'Good',      cls: 'badge-good' };
    if (score >= 60) return { label: 'Average',   cls: 'badge-average' };
    return               { label: 'Poor',      cls: 'badge-poor' };
}

function initials(name) {
    return name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
}

function filteredSorted() {
    let data = [...MOCK_EMPLOYEES];
    
    // Filter by Search
    if (state.search) {
        const q = state.search.toLowerCase();
        data = data.filter(e => e.name.toLowerCase().includes(q) || e.role.toLowerCase().includes(q) || e.dept.toLowerCase().includes(q));
    }
    
    // Filter by Department
    if (state.dept !== 'All') {
        data = data.filter(e => e.dept === state.dept);
    }
    
    // Filter by Project
    if (state.project !== 'All Projects') {
        data = data.filter(e => e.projects.some(p => p.name === state.project));
    }
    
    // Sort
    data.sort((a, b) => {
        // If sorting by project-specific score and a project is selected
        let valA = a[state.sortBy];
        let valB = b[state.sortBy];
        
        if (state.project !== 'All Projects' && ['tasks', 'score'].includes(state.sortBy)) {
            const pA = a.projects.find(p => p.name === state.project);
            const pB = b.projects.find(p => p.name === state.project);
            if (pA) valA = pA[state.sortBy];
            if (pB) valB = pB[state.sortBy];
        }

        const v = state.sortDir === 'asc' ? 1 : -1;
        if (valA < valB) return -v;
        if (valA > valB) return v;
        return 0;
    });
    
    return data;
}

function avgMetric(key) {
    let sum = 0;
    let count = 0;
    
    if (state.project !== 'All Projects' && ['tasks', 'score'].includes(key)) {
        MOCK_EMPLOYEES.forEach(e => {
            const p = e.projects.find(pr => pr.name === state.project);
            if (p) {
                sum += p[key];
                count++;
            }
        });
    } else {
        MOCK_EMPLOYEES.forEach(e => {
            sum += e[key];
            count++;
        });
    }
    
    if (count === 0) return 0;
    return Math.round(sum / count);
}

function progressColor(pct) {
    if (pct >= 90) return '#10b981';
    if (pct >= 75) return '#0ea5e9';
    if (pct >= 60) return '#f59e0b';
    return '#ef4444';
}

function showToast(msg, type = 'success') {
    const t = document.getElementById('perf-toast');
    t.innerHTML = `<i data-lucide="${type === 'success' ? 'check-circle' : 'alert-circle'}" style="width:16px;height:16px;"></i> ${msg}`;
    t.style.background = type === 'success' ? '#1e293b' : '#ef4444';
    t.classList.add('show');
    if (window.lucide) lucide.createIcons();
    setTimeout(() => t.classList.remove('show'), 3200);
}
