<?php
// whatsapp_sales_api/WhatsAppClient.php

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/helper.php'; // For sales helper functions

class SalesWhatsAppClient
{
    private $phoneNumberId;
    private $businessAccountId;
    private $accessToken;
    private $apiUrl;

    public function __construct()
    {
        $this->phoneNumberId = SALES_WHATSAPP_PHONE_NUMBER_ID;
        $this->businessAccountId = defined('SALES_WHATSAPP_BUSINESS_ACCOUNT_ID') ? SALES_WHATSAPP_BUSINESS_ACCOUNT_ID : null;
        $this->accessToken = SALES_WHATSAPP_ACCESS_TOKEN;
        $this->apiUrl = 'https://graph.facebook.com/' . GRAPH_API_VERSION . '/' . $this->phoneNumberId . '/messages';
    }

    public function getTemplates()
    {
        if (!$this->businessAccountId) {
            return ['error' => 'Business Account ID not configured'];
        }

        $url = 'https://graph.facebook.com/' . GRAPH_API_VERSION . '/' . $this->businessAccountId . '/message_templates?limit=250';

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $this->accessToken
        ]);

        $result = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            return ['error' => $error];
        }

        return json_decode($result, true);
    }

    public function sendMessage($to, $messageBody)
    {
        // Basic phone cleaning
        $phone = preg_replace('/[^0-9]/', '', $to);
        if (strlen($phone) == 10)
            $phone = '91' . $phone; // Default to India if no country code

        $data = [
            'messaging_product' => 'whatsapp',
            'to' => $phone,
            'type' => 'text',
            'text' => [
                'body' => $messageBody
            ]
        ];

        $result = $this->sendRequest($data);

        // Log to database using sales logger
        if (isset($result['messages'][0]['id'])) {
            $waId = $result['messages'][0]['id'];
            logSalesWhatsAppMessage($waId, $phone, 'outbound', 'text', $messageBody, 'sent');
        }

        return $result;
    }

    public function sendTemplateMessage($to, $templateName, $languageCode = 'en_US', $components = [])
    {
        $data = [
            'messaging_product' => 'whatsapp',
            'to' => $to,
            'type' => 'template',
            'template' => [
                'name' => $templateName,
                'language' => [
                    'code' => $languageCode
                ]
            ]
        ];

        if (!empty($components)) {
            $data['template']['components'] = $components;
        }

        $result = $this->sendRequest($data);

        // Log to database with extracted parameters
        if (isset($result['messages'][0]['id'])) {
            $waId = $result['messages'][0]['id'];

            // Extract parameter values from components to create readable message
            $messageBody = "📋 [SALES] Template: $templateName";
            if (!empty($components)) {
                $params = [];
                foreach ($components as $component) {
                    if (isset($component['parameters'])) {
                        foreach ($component['parameters'] as $param) {
                            if (isset($param['text'])) {
                                $params[] = $param['text'];
                            }
                        }
                    }
                }
                if (!empty($params)) {
                    $messageBody .= "\n\nParameters:\n" . implode("\n", $params);
                }
            }

            logSalesWhatsAppMessage($waId, $to, 'outbound', 'template', $messageBody, 'sent');
        }

        return $result;
    }

    public function uploadMedia($filePath, $mimeType = 'application/pdf')
    {
        $url = 'https://graph.facebook.com/' . GRAPH_API_VERSION . '/' . $this->phoneNumberId . '/media';

        $cfile = new CURLFile($filePath, $mimeType, basename($filePath));

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, [
            'file' => $cfile,
            'type' => $mimeType,
            'messaging_product' => 'whatsapp'
        ]);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $this->accessToken
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $result = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            logSalesDebug("WA Sales Media Upload ERROR: " . $error);
            return null;
        }

        $response = json_decode($result, true);
        if (isset($response['id'])) {
            // Log successful upload
            logSalesDebug("WA Sales Media Upload SUCCESS. ID: " . $response['id']);
            return $response['id'];
        }

        logSalesDebug("WA Sales Media Upload FAILED: " . $result);
        return null;
    }

    public function sendDocumentMessage($to, $mediaId, $filename, $caption = '')
    {
        // Basic phone cleaning
        $phone = preg_replace('/[^0-9]/', '', $to);
        if (strlen($phone) == 10)
            $phone = '91' . $phone; // Default to India if no country code

        $data = [
            'messaging_product' => 'whatsapp',
            'to' => $phone,
            'type' => 'document',
            'document' => [
                'id' => $mediaId,
                'caption' => $caption,
                'filename' => $filename
            ]
        ];

        return $this->sendRequest($data);
    }

    public function sendInteractiveButtons($to, $bodyText, $buttonsList, $headerText = '', $footerText = '')
    {
        // Basic phone cleaning
        $phone = preg_replace('/[^0-9]/', '', $to);
        if (strlen($phone) == 10)
            $phone = '91' . $phone; // Default to India if no country code

        $interactive = [
            'type' => 'button',
            'body' => [
                'text' => $bodyText
            ]
        ];

        if (!empty($headerText)) {
            $interactive['header'] = [
                'type' => 'text',
                'text' => $headerText
            ];
        }

        if (!empty($footerText)) {
            $interactive['footer'] = [
                'text' => $footerText
            ];
        }

        $buttons = [];
        foreach ($buttonsList as $index => $btn) {
            // Button label max length is 20 chars
            $label = substr($btn['title'], 0, 20);
            $buttons[] = [
                'type' => 'reply',
                'reply' => [
                    'id' => $btn['id'] ?? ('btn_' . $index),
                    'title' => $label
                ]
            ];
        }

        $interactive['action'] = [
            'buttons' => $buttons
        ];

        $data = [
            'messaging_product' => 'whatsapp',
            'to' => $phone,
            'type' => 'interactive',
            'interactive' => $interactive
        ];

        $result = $this->sendRequest($data);

        // Log to database using sales logger
        if (isset($result['messages'][0]['id'])) {
            $waId = $result['messages'][0]['id'];
            $readableBody = $bodyText;
            if (!empty($buttonsList)) {
                $readableBody .= "\n[Buttons: " . implode(', ', array_map(function($b) { return $b['title']; }, $buttonsList)) . "]";
            }
            logSalesWhatsAppMessage($waId, $phone, 'outbound', 'interactive', $readableBody, 'sent');
        }

        return $result;
    }

    private function sendRequest($data)
    {
        $ch = curl_init($this->apiUrl);

        $headers = [
            'Authorization: Bearer ' . $this->accessToken,
            'Content-Type: application/json'
        ];

        $payload = json_encode($data);

        // Log outgoing payload
        logSalesDebug("WA Sales OUTGOING [$this->phoneNumberId]: " . $payload);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $result = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);

        curl_close($ch);

        if ($error) {
            logSalesDebug("WA Sales cURL ERROR: " . $error);
            return ['error' => $error];
        }

        // Log incoming response
        logSalesDebug("WA Sales RESPONSE ($httpCode): " . $result);

        return json_decode($result, true);
    }
}
?>