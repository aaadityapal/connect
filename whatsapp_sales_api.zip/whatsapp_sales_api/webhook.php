<?php
// whatsapp_sales_api/webhook.php
ini_set('display_errors', 0);
error_reporting(E_ALL);
date_default_timezone_set('Asia/Kolkata');

require_once __DIR__ . '/config.php';

// 1. Handle Verification (GET)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Check for hub_mode and hub_verify_token (PHP converts . to _)
    $hub_mode = $_GET['hub_mode'] ?? '';
    $hub_verify_token = $_GET['hub_verify_token'] ?? '';
    $hub_challenge = $_GET['hub_challenge'] ?? '';

    if ($hub_mode === 'subscribe' && $hub_verify_token === SALES_WHATSAPP_VERIFY_TOKEN) {
        echo $hub_challenge;
        exit;
    }
}

// 2. Handle Incoming Events (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once __DIR__ . '/helper.php';

    try {
        $conn = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        $conn->exec("SET time_zone = '+05:30'");
    } catch (PDOException $e) {
        $conn = null;
        logSalesDebug('Webhook DB connection failed: ' . $e->getMessage());
    }

    $input = file_get_contents('php://input');
    logSalesDebug("Received POST payload: " . $input);

    $data = json_decode($input, true);

    if (isset($data['entry'][0]['changes'][0]['value']['messages'][0])) {
        $message = $data['entry'][0]['changes'][0]['value']['messages'][0];

        $waMessageId = $message['id'];
        $from = $message['from']; // Sender Phone Number
        $timestamp = $message['timestamp'];
        $type = $message['type'];

        $body = '';
        if ($type == 'text') {
            $body = $message['text']['body'];
        } elseif ($type == 'image') {
            $body = 'IMAGE_RECEIVED:' . ($message['image']['id'] ?? 'unknown');
        } elseif ($type == 'interactive') {
            $interactiveType = $message['interactive']['type'] ?? '';
            if ($interactiveType === 'button_reply') {
                $body = $message['interactive']['button_reply']['title'] ?? '';
            } elseif ($interactiveType === 'list_reply') {
                $body = $message['interactive']['list_reply']['title'] ?? '';
            } else {
                $body = "Interactive Reply";
            }
        } else {
            $body = "Received message type: $type";
        }

        // Prefix body with [SALES] to distinguish in shared logs if needed
        $loggedBody = "[SALES] " . $body;

        // --- 1. Log for Dashboard ---
        logSalesWhatsAppMessage($waMessageId, $from, 'inbound', $type, $loggedBody, 'received');

        // If user replied, mark latest outbound message to this phone as read
        // so the UI shows double blue ticks even if status webhook is delayed.
        if ($conn) {
            try {
                $cleanFrom = preg_replace('/[^0-9]/', '', (string)$from);
                $upd = $conn->prepare(
                    "UPDATE sales_whatsapp_messages
                     SET status = 'read'
                     WHERE direction = 'outbound'
                       AND REPLACE(REPLACE(REPLACE(user_phone, '+', ''), ' ', ''), '-', '') LIKE ?
                       AND status IN ('sent','delivered')
                     ORDER BY created_at DESC, id DESC
                     LIMIT 1"
                );
                $like = '%' . $cleanFrom . '%';
                $upd->execute([$like]);
            } catch (Exception $e) {
                logSalesDebug('Error updating outbound status to read on inbound: ' . $e->getMessage());
            }
        }

        // --- 1b. If this inbound message is a reply to a recent campaign message,
        // mark the corresponding campaign_delivery as Replied so the campaign
        // status/logs reflect that the user responded.
        if ($conn) {
            try {
                // normalize phone: digits only, drop leading plus
                $cleanFrom = preg_replace('/[^0-9]/', '', (string)$from);
                // Try to match recent campaign_deliveries for this phone
                $stmt = $conn->prepare(
                    "SELECT cd.id AS delivery_id, cd.client_id, cd.client_name, cd.client_phone, cd.campaign_id
                     FROM campaign_deliveries cd
                     WHERE REPLACE(REPLACE(REPLACE(cd.client_phone, '+', ''), ' ', ''), '-', '') LIKE ?
                       AND cd.status IN ('Sent','Delivered','Read')
                     ORDER BY cd.sent_at DESC, cd.id DESC
                     LIMIT 1"
                );
                $like = '%' . $cleanFrom . '%';
                $stmt->execute([$like]);
                $row = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($row) {
                    $deliveryId = (int)$row['delivery_id'];
                    // Update delivery status to Replied if not already
                    $upd = $conn->prepare('UPDATE campaign_deliveries SET status = "Replied", replied_at = NOW(), updated_at = CURRENT_TIMESTAMP WHERE id = ? AND status != "Replied"');
                    $upd->execute([$deliveryId]);

                    // Insert a campaign_message_logs entry to record the reply
                    $ins = $conn->prepare('INSERT INTO campaign_message_logs (campaign_id, campaign_delivery_id, client_id, client_name, client_phone, template_name, message_id, status, details, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())');
                    $ins->execute([
                        $row['campaign_id'] ?? null,
                        $deliveryId,
                        $row['client_id'] ?? null,
                        $row['client_name'] ?? null,
                        $row['client_phone'] ?? $from,
                        $row['template_name'] ?? null,
                        $waMessageId,
                        'Replied',
                        json_encode(['inbound_body' => $body])
                    ]);

                    logSalesDebug("Marked campaign_delivery {$deliveryId} as Replied due to inbound message $waMessageId from $from");
                }
            } catch (Exception $e) {
                logSalesDebug('Error marking delivery as replied: ' . $e->getMessage());
            }
        }

        // --- 2. Visual Flow Engine / Dynamic Auto-Reply Logic ---
        // Create whatsapp_sessions table dynamically
        if ($conn) {
            try {
                $conn->exec("CREATE TABLE IF NOT EXISTS `whatsapp_sessions` (
                    `phone_number` VARCHAR(50) NOT NULL,
                    `current_node_id` VARCHAR(50) DEFAULT NULL,
                    `variables` TEXT DEFAULT NULL,
                    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (`phone_number`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
            } catch (Exception $e) {
                logSalesDebug('Failed to create whatsapp_sessions table: ' . $e->getMessage());
            }
        }

        // Load visual flow config saved from designer
        $flowJsonPath = dirname(__DIR__) . '/admin/whatsapp_bot_designer/flow.json';
        $flow = null;
        if (file_exists($flowJsonPath)) {
            $flow = json_decode(file_get_contents($flowJsonPath), true);
        }

        // Helper to replace variables
        if (!function_exists('replaceVarsInText')) {
            function replaceVarsInText($text, $vars) {
                foreach ($vars as $k => $v) {
                    if (is_scalar($v)) {
                        $text = str_replace('{{' . $k . '}}', $v, $text);
                    }
                }
                return $text;
            }
        }

        // Helper to find connections
        if (!function_exists('getNextNodeId')) {
            function getNextNodeId($connections, $fromNodeId, $fromPortId) {
                foreach ($connections as $c) {
                    if ($c['fromNode'] === $fromNodeId && $c['fromPort'] === $fromPortId) {
                        return $c['toNode'];
                    }
                }
                return null;
            }
        }

        require_once __DIR__ . '/WhatsAppClient.php';
        $client = new SalesWhatsAppClient();

        if ($flow && isset($flow['nodes']) && isset($flow['connections']) && $conn) {
            logSalesDebug("Processing message through Visual Flow Engine for $from");
            
            // 1. Get current session
            $sessStmt = $conn->prepare("SELECT * FROM whatsapp_sessions WHERE phone_number = ?");
            $sessStmt->execute([$from]);
            $session = $sessStmt->fetch();
            
            $currentNodeId = null;
            $sessionVars = [];
            
            if ($session) {
                $currentNodeId = $session['current_node_id'];
                $sessionVars = json_decode($session['variables'] ?? '[]', true);
            }
            
            // System variables
            $sessionVars['phone'] = $from;
            if (!isset($sessionVars['name'])) {
                $senderName = $data['entry'][0]['changes'][0]['value']['contacts'][0]['profile']['name'] ?? '';
                if ($senderName) {
                    $sessionVars['name'] = $senderName;
                }
            }

            // 2. Check if the incoming message is a Trigger keyword (Start node)
            $cleanMsg = strtolower(trim($body));
            $triggerNode = null;
            
            foreach ($flow['nodes'] as $node) {
                if ($node['type'] === 'trigger') {
                    $keywords = explode(',', strtolower($node['data']['keywords'] ?? ''));
                    foreach ($keywords as $kw) {
                        if (trim($kw) === $cleanMsg) {
                            $triggerNode = $node;
                            break 2;
                        }
                    }
                }
            }
            
            if ($triggerNode) {
                logSalesDebug("Trigger node matched: " . $triggerNode['id']);
                // Reset state
                $sessionVars = ['phone' => $from];
                $senderName = $data['entry'][0]['changes'][0]['value']['contacts'][0]['profile']['name'] ?? '';
                if ($senderName) {
                    $sessionVars['name'] = $senderName;
                }
                
                $currentNodeId = getNextNodeId($flow['connections'], $triggerNode['id'], 'output');
                $sessionVars['_last_executed_node'] = $triggerNode['id'];
            }
            
            // 3. Process current user reply if we were in an active interactive/waiting node
            $processedReply = false;
            
            if (!$triggerNode && $currentNodeId) {
                $activeNode = null;
                foreach ($flow['nodes'] as $node) {
                    if ($node['id'] === $currentNodeId) {
                        $activeNode = $node;
                        break;
                    }
                }
                
                if ($activeNode) {
                    if ($activeNode['type'] === 'form') {
                        $varName = $activeNode['data']['variableName'] ?? 'formVal';
                        $valType = $activeNode['data']['inputType'] ?? 'text';
                        $userInput = trim($body);
                        
                        $isValid = true;
                        if ($valType === 'email') {
                            $isValid = filter_var($userInput, FILTER_VALIDATE_EMAIL) !== false;
                        } elseif ($valType === 'phone') {
                            $isValid = preg_match('/^[0-9+ \-]{8,20}$/', $userInput);
                        } elseif ($valType === 'number') {
                            $isValid = is_numeric($userInput);
                        }
                        
                        if ($isValid) {
                            $sessionVars[$varName] = $userInput;
                            logSalesDebug("Form input valid: saved '$varName' = '$userInput'");
                            $currentNodeId = getNextNodeId($flow['connections'], $currentNodeId, 'output');
                            $processedReply = true;
                        } else {
                            logSalesDebug("Form input invalid: $userInput. Re-sending prompt.");
                            $prompt = replaceVarsInText($activeNode['data']['messageText'] ?? 'Please reply with a valid value.', $sessionVars);
                            $client->sendMessage($from, "*Invalid Input!* Please try again:\n\n" . $prompt);
                            
                            $saveSess = $conn->prepare("INSERT INTO whatsapp_sessions (phone_number, current_node_id, variables) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE current_node_id = ?, variables = ?");
                            $saveSess->execute([$from, $currentNodeId, json_encode($sessionVars), $currentNodeId, json_encode($sessionVars)]);
                            
                            echo 'OK';
                            exit;
                        }
                    } elseif ($activeNode['type'] === 'buttons') {
                        $userInput = strtolower(trim($body));
                        $buttonsList = $activeNode['data']['buttons'] ?? [];
                        
                        $matchedIdx = -1;
                        foreach ($buttonsList as $idx => $btnText) {
                            if (strtolower(trim($btnText)) === $userInput) {
                                $matchedIdx = $idx;
                                break;
                            }
                        }
                        
                        if ($matchedIdx !== -1) {
                            $selectedBtnLabel = $buttonsList[$matchedIdx];
                            logSalesDebug("Button choice matched: Index $matchedIdx ($selectedBtnLabel)");
                            $sessionVars['lastButton'] = $selectedBtnLabel;
                            if (isset($activeNode['data']['variableName'])) {
                                $sessionVars[$activeNode['data']['variableName']] = $selectedBtnLabel;
                            }
                            $currentNodeId = getNextNodeId($flow['connections'], $currentNodeId, "btn_$matchedIdx");
                            $processedReply = true;
                        } else {
                            logSalesDebug("Button choice not matched: $userInput. Re-sending menu.");
                            $prompt = replaceVarsInText($activeNode['data']['messageText'] ?? 'Choose an option:', $sessionVars);
                            $buttons = [];
                            foreach ($buttonsList as $idx => $btnText) {
                                $buttons[] = ['id' => "btn_$idx", 'title' => $btnText];
                            }
                            $client->sendInteractiveButtons($from, $prompt, $buttons, "ArchitectsHive", "Select an option");
                            
                            $saveSess = $conn->prepare("INSERT INTO whatsapp_sessions (phone_number, current_node_id, variables) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE current_node_id = ?, variables = ?");
                            $saveSess->execute([$from, $currentNodeId, json_encode($sessionVars), $currentNodeId, json_encode($sessionVars)]);
                            
                            echo 'OK';
                            exit;
                        }
                    }
                }
            }

            // 4. Execution Loop for automatic/non-blocking nodes
            $loopLimit = 20;
            $loopCount = 0;
            
            while ($currentNodeId && $loopCount < $loopLimit) {
                $loopCount++;
                
                $node = null;
                foreach ($flow['nodes'] as $n) {
                    if ($n['id'] === $currentNodeId) {
                        $node = $n;
                        break;
                    }
                }
                
                if (!$node) {
                    logSalesDebug("Node not found for ID: $currentNodeId");
                    $currentNodeId = null;
                    break;
                }
                
                logSalesDebug("Executing node: {$node['id']} ({$node['type']})");
                
                if ($node['type'] === 'message') {
                    $txt = replaceVarsInText($node['data']['messageText'] ?? '', $sessionVars);
                    $client->sendMessage($from, $txt);
                    
                    $currentNodeId = getNextNodeId($flow['connections'], $node['id'], 'output');
                } elseif ($node['type'] === 'media') {
                    $mediaUrl = $node['data']['mediaUrl'] ?? '';
                    $mediaType = $node['data']['mediaType'] ?? 'image';
                    $caption = replaceVarsInText($node['data']['captionText'] ?? '', $sessionVars);
                    
                    // Simple media fallback send
                    $client->sendMessage($from, "$caption\n\n[Attached Media: $mediaUrl]");
                    $currentNodeId = getNextNodeId($flow['connections'], $node['id'], 'output');
                } elseif ($node['type'] === 'wait') {
                    $duration = intval($node['data']['duration'] ?? 2);
                    sleep(min($duration, 3)); // Max 3s to avoid timeout
                    
                    $currentNodeId = getNextNodeId($flow['connections'], $node['id'], 'output');
                } elseif ($node['type'] === 'condition') {
                    $var = $node['data']['variableName'] ?? '';
                    $op = $node['data']['operator'] ?? 'equals';
                    $val = strtolower(trim($node['data']['value'] ?? ''));
                    $actualVal = strtolower(trim($sessionVars[$var] ?? ''));
                    
                    $condPassed = false;
                    if ($op === 'equals') {
                        $condPassed = ($actualVal == $val);
                    } elseif ($op === 'contains') {
                        $condPassed = (strpos($actualVal, $val) !== false);
                    } elseif ($op === 'starts_with') {
                        $condPassed = (strpos($actualVal, $val) === 0);
                    }
                    
                    $port = $condPassed ? 'yes' : 'no';
                    $currentNodeId = getNextNodeId($flow['connections'], $node['id'], $port);
                } elseif ($node['type'] === 'ai') {
                    $sysPrompt = $node['data']['promptText'] ?? '';
                    $varName = $node['data']['variableName'] ?? 'aiResponse';
                    
                    // Simulate Gemini or smart dynamic assistant response
                    $aiResponseText = "Hello " . ($sessionVars['name'] ?? 'there') . "! I see you wanted info. Our custom design services cover your inputs:\nLocation: " . ($sessionVars['projectLocation'] ?? 'N/A') . "\nEmail: " . ($sessionVars['userEmail'] ?? 'N/A') . "\nWe would love to help you build!";
                    
                    $sessionVars[$varName] = $aiResponseText;
                    $client->sendMessage($from, $aiResponseText);
                    
                    $currentNodeId = getNextNodeId($flow['connections'], $node['id'], 'output');
                } elseif ($node['type'] === 'database') {
                    $tableName = $node['data']['tableName'] ?? 'leads';
                    $mappings = $node['data']['mappings'] ?? [];
                    
                    try {
                        $cols = [];
                        $vals = [];
                        $params = [];
                        
                        foreach ($mappings as $m) {
                            $col = preg_replace('/[^a-zA-Z0-9_]/', '', $m['colName']);
                            $varName = $m['varName'];
                            $val = $sessionVars[$varName] ?? '';
                            
                            $cols[] = "`$col`";
                            $vals[] = "?";
                            $params[] = $val;
                        }
                        
                        // For lead integration, auto-include whatsapp_number/phone if not set
                        if (!in_array('`whatsapp_number`', $cols) && !in_array('`phone`', $cols)) {
                            if ($tableName === 'pricing_share_leads') {
                                $cols[] = '`whatsapp_number`';
                                $vals[] = '?';
                                $params[] = preg_replace('/[^0-9]/', '', $from);
                            }
                        }
                        
                        if (!in_array('`created_at`', $cols)) {
                            $cols[] = '`created_at`';
                            $vals[] = 'NOW()';
                        }
                        
                        if (!empty($cols)) {
                            $sql = "INSERT INTO `$tableName` (" . implode(', ', $cols) . ") VALUES (" . implode(', ', $vals) . ")";
                            $insStmt = $conn->prepare($sql);
                            $insStmt->execute($params);
                            logSalesDebug("Database Save Success on table $tableName: ID " . $conn->lastInsertId());
                        }
                    } catch (Exception $e) {
                        logSalesDebug("Database Save Failed: " . $e->getMessage());
                    }
                    
                    $currentNodeId = getNextNodeId($flow['connections'], $node['id'], 'output');
                } elseif ($node['type'] === 'webhook') {
                    $url = $node['data']['url'] ?? '';
                    $method = $node['data']['method'] ?? 'POST';
                    $bodyTpl = $node['data']['bodyTemplate'] ?? '';
                    
                    $resolvedBody = replaceVarsInText($bodyTpl, $sessionVars);
                    
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
                    if (strtoupper($method) === 'POST') {
                        curl_setopt($ch, CURLOPT_POST, true);
                        curl_setopt($ch, CURLOPT_POSTFIELDS, $resolvedBody);
                        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
                    }
                    curl_exec($ch);
                    curl_close($ch);
                    
                    $currentNodeId = getNextNodeId($flow['connections'], $node['id'], 'output');
                } elseif ($node['type'] === 'quote_pdf') {
                    // --- QUOTATION PDF GENERATOR ---
                    // Fires when the "Generate Quote PDF" node is reached in the flow.
                    // Loads generate_whatsapp_quote_pdf.php and calls the main function.
                    try {
                        require_once __DIR__ . '/generate_whatsapp_quote_pdf.php';
                        generateAndSendQuotePDF($from, $sessionVars);
                        logSalesDebug("quote_pdf: Quotation sent to $from");
                    } catch (Exception $e) {
                        logSalesDebug("quote_pdf: Error - " . $e->getMessage());
                        $client->sendMessage($from, "We have received your details! Our team will send you a detailed quotation shortly. 📄");
                    }
                    $currentNodeId = getNextNodeId($flow['connections'], $node['id'], 'output');
                } elseif ($node['type'] === 'form') {
                    $prompt = replaceVarsInText($node['data']['messageText'] ?? '', $sessionVars);
                    $client->sendMessage($from, $prompt);
                    break;
                } elseif ($node['type'] === 'buttons') {
                    $prompt = replaceVarsInText($node['data']['messageText'] ?? '', $sessionVars);
                    $buttonsList = $node['data']['buttons'] ?? [];
                    
                    $buttons = [];
                    foreach ($buttonsList as $idx => $btnText) {
                        $buttons[] = ['id' => "btn_$idx", 'title' => $btnText];
                    }
                    $client->sendInteractiveButtons($from, $prompt, $buttons, "ArchitectsHive", "Select an option");
                    break;
                } else {
                    $currentNodeId = null;
                }
            }
            
            // 5. Save session state at the end of step
            if ($currentNodeId) {
                $saveSess = $conn->prepare("INSERT INTO whatsapp_sessions (phone_number, current_node_id, variables) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE current_node_id = ?, variables = ?");
                $saveSess->execute([$from, $currentNodeId, json_encode($sessionVars), $currentNodeId, json_encode($sessionVars)]);
            } else {
                $delSess = $conn->prepare("DELETE FROM whatsapp_sessions WHERE phone_number = ?");
                $delSess->execute([$from]);
                logSalesDebug("Visual Flow finished for $from. Session cleared.");
            }
            
        } else {
            logSalesDebug("Visual Flow json not found or DB missing. Running fallback static auto-reply.");
            // --- Fallback Static Auto-Reply Logic ---
            $cleanMsg = strtolower(trim($body));
            $greetings = ['hi', 'hello', 'hey', 'start', 'menu', 'hlo', 'hii', 'get started'];
            $isGreeting = false;
            foreach ($greetings as $g) {
                if ($cleanMsg === $g) {
                    $isGreeting = true;
                    break;
                }
            }

            if ($isGreeting) {
                $buttons = [
                    ['id' => 'menu_book', 'title' => 'Book Appointment'],
                    ['id' => 'menu_quote', 'title' => 'Get Quotation'],
                    ['id' => 'menu_pricing', 'title' => 'Pricing Plans']
                ];
                $client->sendInteractiveButtons(
                    $from,
                    "Hello! Welcome to ArchitectsHive. 🏠🚀\n\nHow can we help you today? Please choose one of the options below to get started:",
                    $buttons,
                    "ArchitectsHive",
                    "Select a response below"
                );
            } elseif (strpos($cleanMsg, 'book') !== false || strpos($cleanMsg, 'appointment') !== false) {
                $reply = "Great! Let's book your architectural consultation. Click the link below to select a convenient date and time:\n\n📅 https://archweb.com/book-appointment\n\nWe look forward to working with you!";
                $client->sendMessage($from, $reply);
            } elseif (strpos($cleanMsg, 'quote') !== false || strpos($cleanMsg, 'quotation') !== false) {
                $reply = "Sure! You can easily calculate estimated construction and design costs using our visual builder:\n\n📐 https://archweb.com/quotation-builder\n\nIt takes less than 2 minutes to estimate your plans!";
                $client->sendMessage($from, $reply);
            } elseif (strpos($cleanMsg, 'pricing') !== false || strpos($cleanMsg, 'plans') !== false || strpos($cleanMsg, 'rate') !== false) {
                $reply = "Explore our ready-to-use blueprints, pricing plans, and rate cards:\n\n💵 https://archweb.com/plans\n\nFeel free to ask if you have questions about specific packages!";
                $client->sendMessage($from, $reply);
            } else {
                $reply = "Thank you for reaching out to ArchitectsHive.\n\nReply with *hi* or *menu* to display our interactive choices, or type *book* to request an appointment.";
                $client->sendMessage($from, $reply);
            }
        }
    }

    if (isset($data['entry'][0]['changes'][0]['value']['statuses'][0]) && $conn) {
        $tableStmt = $conn->query("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'campaign_message_logs'");
        $hasCampaignLogTable = (int)$tableStmt->fetchColumn() > 0;
        if (!$hasCampaignLogTable) {
            echo 'OK';
            exit;
        }
        $status = $data['entry'][0]['changes'][0]['value']['statuses'][0];
        $waMessageId = $status['id'] ?? null;
        $messageStatus = strtolower((string)($status['status'] ?? 'unknown'));
        $timestamp = isset($status['timestamp']) ? date('Y-m-d H:i:s', (int)$status['timestamp']) : date('Y-m-d H:i:s');
        $recipientId = $status['recipient_id'] ?? null;
        $conversation = $status['conversation']['id'] ?? null;
        $errors = $status['errors'] ?? null;

        if ($waMessageId) {
            // 1. Update our new sales_whatsapp_messages table (Real ticks!)
            $statusEnum = 'sent';
            if ($messageStatus === 'delivered') $statusEnum = 'delivered';
            elseif ($messageStatus === 'read' || $messageStatus === 'seen') $statusEnum = 'read';
            elseif ($messageStatus === 'failed') $statusEnum = 'failed';

            $updSales = $conn->prepare("UPDATE sales_whatsapp_messages SET status = ? WHERE wa_message_id = ?");
            $updSales->execute([$statusEnum, $waMessageId]);
            logSalesDebug("Updated sales_whatsapp_messages status for $waMessageId to $statusEnum");

            // 2. Original campaign logging fallback
            $stmt = $conn->prepare('SELECT id, campaign_id, campaign_delivery_id, client_id, client_name, client_phone, template_name FROM campaign_message_logs WHERE message_id = ? ORDER BY id DESC LIMIT 1');
            $stmt->execute([$waMessageId]);
            $logRow = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($logRow) {
                $details = [
                    'recipient_id' => $recipientId,
                    'conversation_id' => $conversation,
                    'errors' => $errors,
                ];

                $conn->prepare('INSERT INTO campaign_message_logs (campaign_id, campaign_delivery_id, client_id, client_name, client_phone, template_name, message_id, status, details, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())')
                    ->execute([
                        $logRow['campaign_id'],
                        $logRow['campaign_delivery_id'],
                        $logRow['client_id'],
                        $logRow['client_name'],
                        $logRow['client_phone'],
                        $logRow['template_name'],
                        $waMessageId,
                        ucfirst($messageStatus),
                        json_encode($details)
                    ]);

                $updateMap = [
                    'sent' => 'Sent',
                    'delivered' => 'Delivered',
                    'read' => 'Read',
                    'failed' => 'Failed',
                ];
                $newStatus = $updateMap[$messageStatus] ?? ucfirst($messageStatus);

                $columnMap = [
                    'Sent' => ['status' => 'Sent', 'column' => 'sent_at'],
                    'Delivered' => ['status' => 'Delivered', 'column' => 'delivered_at'],
                    'Read' => ['status' => 'Read', 'column' => 'read_at'],
                    'Failed' => ['status' => 'Failed', 'column' => 'error_message'],
                ];

                if ($newStatus === 'Sent') {
                    $conn->prepare('UPDATE campaign_deliveries SET status = "Sent", sent_at = COALESCE(sent_at, FROM_UNIXTIME(?)), updated_at = CURRENT_TIMESTAMP WHERE id = ?')
                        ->execute([(int)$timestamp, (int)$logRow['campaign_delivery_id']]);
                } elseif ($newStatus === 'Delivered') {
                    $conn->prepare('UPDATE campaign_deliveries SET status = "Delivered", delivered_at = FROM_UNIXTIME(?), updated_at = CURRENT_TIMESTAMP WHERE id = ?')
                        ->execute([(int)$timestamp, (int)$logRow['campaign_delivery_id']]);
                } elseif ($newStatus === 'Read') {
                    $conn->prepare('UPDATE campaign_deliveries SET status = "Read", read_at = FROM_UNIXTIME(?), updated_at = CURRENT_TIMESTAMP WHERE id = ?')
                        ->execute([(int)$timestamp, (int)$logRow['campaign_delivery_id']]);
                } elseif ($newStatus === 'Failed') {
                    $conn->prepare('UPDATE campaign_deliveries SET status = "Failed", error_message = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
                        ->execute([json_encode($errors), (int)$logRow['campaign_delivery_id']]);
                }
            }
        }
    }

    echo 'OK';
    exit;
}
?>