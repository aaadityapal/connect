<?php
// whatsapp_sales_api/config.php

// Sales WhatsApp Configuration
// These constants are prefixed with SALES_ to avoid conflict with the default config

define('SALES_WHATSAPP_VERIFY_TOKEN', 'sales_secret_696969'); // Matches your manual update
define('SALES_WHATSAPP_PHONE_NUMBER_ID', '892965963910715'); // Provided by user
define('SALES_WHATSAPP_ACCESS_TOKEN', 'EAATHxtWRbN8BQhhpHFCmC4Fg6YSPSN6hwXQz8QEj0r9BUaDXiEMJxsAp4sv5q7F73LOnbkiaLjz5roXl2qFIJxjZBYJDdKMVIqGYnxzoI3AZAPJKRMEZC6Pj8NO78filSN6f0BJ9UT0WtM7iIJYx48QF8wLovMPdLc4Q2SvMrjbgjMuj3An0nfru350fDJjaAZDZD'); // User needs to provide this
define('SALES_WHATSAPP_BUSINESS_ACCOUNT_ID', '2044076599773351'); // Provided by user
define('GRAPH_API_VERSION', 'v21.0'); // Using a general graph API version unless specified otherwise

?>